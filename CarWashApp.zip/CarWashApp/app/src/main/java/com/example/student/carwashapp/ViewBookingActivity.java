package com.example.student.carwashapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ViewBookingActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_booking);
        //final DataBaseHandler db = new DataBaseHandler(this);
        String regno = getIntent().getExtras().getString("com.example.student.carwashapp.REGNO");
        String bookdate = getIntent().getExtras().getString("com.example.student.carwashapp.DATE");
        String services = getIntent().getExtras().getString("com.example.student.carwashapp.SERV");

        TextView tregno = findViewById(R.id.txtRegNo);
        tregno.setText(regno);

        TextView tdate = findViewById(R.id.txtdate);
        tdate.setText(bookdate);

        TextView tservice = findViewById(R.id.txtservice);
        tservice.setText(services);

        Button btnLogOff = (Button) findViewById(R.id.btnLogOff);
        btnLogOff.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startIntent = new Intent(getApplicationContext(), LogInActivity.class);

                startActivity(startIntent);
            }
        });

        Button btnAddBooking = (Button) findViewById(R.id.btnAddBooking);
        btnAddBooking.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startIntent = new Intent(getApplicationContext(), AddBookingActivity.class);

                startActivity(startIntent);
            }
        });

        Button btnViewBooking = (Button) findViewById(R.id.btnViewBook);
        btnViewBooking.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startIntent = new Intent(getApplicationContext(), ViewBookingActivity.class);

                startActivity(startIntent);
            }
        });

    }
}
