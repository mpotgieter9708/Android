package com.example.student.carwashapp;

public class Booking {

    int bookNum;
    String date;
    String Regno;
    String service;

    public Booking()
    {

    }

  public  Booking(int bookNum,String Regno, String date, String service)
  {
      this.date = date;
      this.bookNum =bookNum;
      this.Regno = Regno;
      this.service = service;
}
    public  Booking(String Regno, String date, String service) {
        this.date = date;

        this.Regno = Regno;
        this.service = service;
    }
  public int getBookNum(){return bookNum;}
  public String getReg_no(){return Regno;}
  public String getDate(){return date;}
  public String getService() {return service;}

  public int getbookNum() {return bookNum;}

    public void setRegno(String regno) {Regno = regno;}
    public void setDate(String date){this.date = date;}
    public void setService(String service) {this.service = service; }

    public void setBookNum(int bookNum) { this.bookNum = bookNum; }
}