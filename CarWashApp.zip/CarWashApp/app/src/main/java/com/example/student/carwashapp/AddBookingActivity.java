package com.example.student.carwashapp;

        import android.content.Intent;
        import android.os.Bundle;
        import android.support.v7.app.AppCompatActivity;
        import android.view.View;
        import android.widget.ArrayAdapter;
        import android.widget.Button;
        import android.widget.EditText;
        import android.widget.Spinner;
        import android.widget.TextView;

public class AddBookingActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_booking);
        final DataBaseHandler db = new DataBaseHandler(this);
        String surname = getIntent().getExtras().getString("com.example.student.carwashapp.SURNAME");
        String initials = getIntent().getExtras().getString("com.example.student.carwashapp.INITIALS");
        final String regno = getIntent().getExtras().getString("com.example.student.carwashapp.REGNO");
        final EditText edtxtRegNo = findViewById(R.id.edtxtRegno);
        final EditText edsdate = findViewById(R.id.edtxtdate);
        edtxtRegNo.setText(regno);
        TextView cust = findViewById(R.id.txtName);
        cust.setText("Hello, " + surname + " " + initials + "!");
        final Spinner myspinner = (Spinner)findViewById(R.id.spinner1);

        ArrayAdapter<String> myAdapter = new ArrayAdapter<String>(AddBookingActivity.this,
                android.R.layout.simple_list_item_1,getResources().getStringArray(R.array.names));
        myAdapter.setDropDownViewResource((android.R.layout.simple_spinner_dropdown_item));
        myspinner.setAdapter(myAdapter);

        Button btnLogin = (Button) findViewById(R.id.btnLogin);
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startIntent = new Intent(getApplicationContext(), LogInActivity.class);

                startActivity(startIntent);
            }
        });

        Button btnAddBooking = (Button) findViewById(R.id.btnAddBooking);
        btnAddBooking.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startIntent = new Intent(getApplicationContext(), AddBookingActivity.class);

                startActivity(startIntent);
            }
        });

        Button btnViewBooking = (Button) findViewById(R.id.btnViewBook);
        btnViewBooking.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startIntent = new Intent(getApplicationContext(), ViewBookingActivity.class);

                startActivity(startIntent);

            }
        });

        Button btnAdd = (Button) findViewById(R.id.btnAdd);
        btnAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView display = findViewById(R.id.txtError);
                try{
                    db.addBooking(new Booking(edtxtRegNo.getText().toString(),edsdate.getText().toString(),myspinner.getSelectedItem().toString()));
                    display.setText("Your booking was successfull");
                    //Intent startIntent = new Intent(getApplicationContext(), ViewBookingActivity.class);
                    //startIntent.putExtra("com.example.student.carwashapp.REGNO",regno);
                    //startActivity(startIntent);
                }
                catch(Exception ex){
                    display.setText("Your booking was unsuccessfull");
                }



            }
        });

    }
}
