package com.example.student.carwashapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DataBaseHandler extends SQLiteOpenHelper
{
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "carwash";
    private static final String TABLE_CLIENT = "client";
    private static final String KEY_ID = "id";
    private static final String KEY_SURNAME = "surname";
    private static final String KEY_INITIALS = "initials";
    private static final String KEY_PH_NO = "phone_number";
    private static final String KEY_EMAIL = "email";
    private static final String KEY_REGNO = "registration_number";
    private static final String KEY_USERNAME = "username";
    private static final String KEY_PASSWORD = "password";

    public DataBaseHandler(Context context)
    {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);

    }

    @Override
    public void onCreate(SQLiteDatabase db)
    {
        String CREATE_CLIENT_TABLE = "CREATE TABLE " + TABLE_CLIENT  + "("
                + KEY_ID + " INTEGER PRIMARY KEY AUTOINCREMENT," + KEY_SURNAME + " TEXT," + KEY_INITIALS + " TEXT,"
                + KEY_PH_NO + " TEXT," + KEY_EMAIL + " TEXT," + KEY_REGNO  + " TEXT," + KEY_USERNAME + " TEXT," + KEY_PASSWORD  + " TEXT" + ")";
        db.execSQL(CREATE_CLIENT_TABLE);

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_CLIENT);
        onCreate(db);

    }

    void addClient(Client client)
    {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_SURNAME,client.getSurname());
        values.put(KEY_INITIALS,client.getInitials());
        values.put(KEY_PH_NO,client.getPhone());
        values.put(KEY_EMAIL,client.getEmail());
        values.put(KEY_REGNO,client.getRegno());
        values.put(KEY_USERNAME,client.getUsername());
        values.put(KEY_PASSWORD,client.getPassword());

        db.insert(TABLE_CLIENT,null,values);
        //insert
        db.close();

    }

    Client getClient(String username)
    {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABLE_CLIENT, new String[]{KEY_ID,KEY_SURNAME,KEY_INITIALS,KEY_PH_NO,KEY_EMAIL,KEY_REGNO,KEY_USERNAME,KEY_PASSWORD},KEY_USERNAME+"=?",new String[]{String.valueOf(username)},null,null,null,null);
        Client client;
        if(cursor!=null)
        {
            cursor.moveToFirst();
            String key = cursor.getString(0);
            String surname = cursor.getString(1);
            String initials = cursor.getString(2);
            String phone = cursor.getString(3);
            String email = cursor.getString(4);
            String regno = cursor.getString(5);
            String login_name = cursor.getString(6);
            String password = cursor.getString(7);
            client = new Client(Integer.parseInt(key),surname,initials,phone,email,regno,login_name,password);

        }
        else
        {
            client = new Client(1,"defaultname","defaultInit","defaultNumber","defaultemail","defaultregno","defaultusername","defaultpassword");

        }
        return client;

    }

}
