package com.example.student.carwashapp;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class LogInActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_log_in);
        final DataBaseHandler db = new DataBaseHandler(this);
        final EditText username = findViewById(R.id.edtUsername);
        final EditText password = findViewById(R.id.edtPassword);
        Button btnHome = (Button) findViewById(R.id.btnHome);
        btnHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startIntent = new Intent(getApplicationContext(), HomeActivity.class);

                startActivity(startIntent);
            }
        });

        Button btnAbout = (Button) findViewById(R.id.btnAbout);
        btnAbout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startIntent = new Intent(getApplicationContext(), AboutActivity.class);

                startActivity(startIntent);
            }
        });
        Button btnLogin = (Button) findViewById(R.id.btnLogin);
        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startIntent = new Intent(getApplicationContext(), LogInActivity.class);

                startActivity(startIntent);
            }
        });
        Button btnRegister = (Button) findViewById(R.id.btnRegister);
        btnRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent startIntent = new Intent(getApplicationContext(), RegisterActivity.class);

                startActivity(startIntent);
            }
        });

        Button btnProceed = (Button) findViewById(R.id.btnProceed);
        btnProceed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView display = findViewById(R.id.txtDisplay);
                try {
                    Client myclient = db.getClient(username.getText().toString());
                    String user = myclient.getUsername();
                    String name = myclient.getSurname();
                    String init = myclient.getInitials();
                    String regno = myclient.getRegno();
                    Intent startIntent = new Intent(getApplicationContext(), AddBookingActivity.class);
                    startIntent.putExtra("carwashapp.student.example.com.SURNAME",name);
                    startIntent.putExtra("carwashapp.student.example.com.INITIALS",init);
                    startIntent.putExtra("carwashapp.student.example.com.REGNO",regno);
                    startActivity(startIntent);

                }
                catch (Exception ex){
                    display.setText("An error occured you could not login!");
                }
            }


        });
    }
}
